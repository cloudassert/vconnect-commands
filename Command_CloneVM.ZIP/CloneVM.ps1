# *************************************************************************************** #
# Cloning VM
# *************************************************************************************** #


# *************************************************************************************** #
# Params in @(paramName) will be replaced by vConnect. These are standard, DO NOT CHANGE
# *************************************************************************************** #

<# End Of Arguments #>

# Common Functions - Do not Remove this
. .\ExtensionsCommon.ps1
. .\OnCreateVM_SelectDataStore.ps1


# *************************************************************************************** #
# Do custom processing here.
# *************************************************************************************** #

try 
{   
    $connection = VConnect-Connect-VIServer -ErrorAction Stop
    
    $location = VConnect-GetLocation $Datacenter $Cluster $FolderName $RootFolderPath $ResourcePoolName $false
    if($location) 
    {
        $newVm = Get-VM -Name $NewVMName
	    $originalVM = $location | Get-VM -Name $VMName
        $VMHost = Get-VMHost -VM $VMName
        if($originalVM ) 
        {
            $memoryMB = $originalVM.MemoryMB

            # Get the Hard Disks size of the original VM
            $hardDisks = $originalVM | Get-HardDisk | Measure-Object 'CapacityGB' -Sum
            $diskGB = $hardDisks.Sum
            
            # Minimum space required = (Size of template's hard disk(s)) + (size of RAM for virtual machine) + ( 100 MB for log files per virtual machine)
            $diskSpaceRequiredGB = $diskGB + ($memoryMB / 1024) + (100 / 1024) 
            
            # Folder where the Original VM is placed
            $folder =  VConnect-GetVMFolder $FolderName $Datacenter $RootFolderPath $false
            
            # Get Accessible Datastores of this VCenter Cluster
            $vcenterCluster = Get-Cluster -Name $Cluster
            $allDataStores = $vcenterCluster  | Get-DataStore | ?{ $_.Accessible }
            
            # Find the relevant Datastore
            $datastore = -VConnect-SelectDataStoreForVM $allDataStores $diskSpaceRequiredGB $DataStoreHint
            $datastoreName = $datastore.Values[0].Name

	        if($newVm )
	        {
		        throw "Failure Cloning the VM. The VM with the specified name already exists."
	        }
	        $clonedVM = New-VM -Name $NewVMName -VM $originalVM -Datastore $datastoreName -VMHost $VMHost -Location $folder -ResourcePool $ResourcePoolName           
            $clonedVM | Start-VM -ErrorAction Stop
            if (!$?)
            {
                $errorMessage = "Failure cloning the VM.`nError Message:`n"
                $errorMessage += $error[0].ToString()
                throw $errorMessage 
            }
            $resultObj = @{
                NewVMName = $clonedVM.Name
            }
            $result = New-Object PSObject -Property $resultObj
            return Get-ScriptResult $true 0 "Cloning of the VM Succeeded" $result	    
        }
    }
    else
    {
        throw "Failure cloning the VM. The parent folder/resource pool is not found."
    }
}
catch 
{
    $errorMessage = $_.Exception.Message
    $exception = Get-FullLastError
    return Get-ScriptErrorResult $errorMessage $exception  
}
