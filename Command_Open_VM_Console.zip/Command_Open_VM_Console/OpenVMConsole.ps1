# *************************************************************************************** #
# Adding additional Disks to VM
# *************************************************************************************** #


# *************************************************************************************** #
# Params in @(paramName) will be replaced by vConnect. These are standard, DO NOT CHANGE
# *************************************************************************************** #

<# End Of Arguments #>

# Common Functions - Do not Remove this
. .\ExtensionsCommon.ps1


# *************************************************************************************** #
# Do custom processing here.
# *************************************************************************************** #

try 
{   
    #$connection = VConnect-Connect-VIServer -ErrorAction Stop
    $connection = Connect-VIServer -Server $HostServerName -Port $HostServerPort -User $ConsoleUserName -Password $ConsoleUserPassword -NotDefault -ErrorAction Stop


    $location = VConnect-GetLocation $Datacenter $Cluster $FolderName $RootFolderPath $ResourcePoolName $false $connection
    if($location) 
    {
        $vm = $location | Get-VM -Name $VMName -Server $connection
        if($vm) 
        {
            $url = $vm | Open-VMConsoleWindow -UrlOnly -Server $connection
            if($url -eq $null) {
                throw $Error[0]
            }
            $qsSplilt = $url.Split("?")
            $qs = $qsSplilt[1]
            $qpSplit = $qs.Split("&")
            $qureyParams = @{}
            foreach($kv in $qpSplit){
                $k = $kv.Split("=")[0];
                $v = $kv.Split("=")[1];
                $qureyParams.Add($k,$v);
            }
            $moid = $qureyParams["vmid"]
            $vmName = $qureyParams["vmName"]
            $vCenterHost = $qureyParams["host"]
            $ticket = $qureyParams["ticket"]
            #vmrc://clone:cst-VCT-521cbb38-0ce9-9a91-5ef0-987c94a12676--tp-FF-B7-A2-5D-36-56-F0-34-19-82-36-FC-70-CB-43-CD-8C-E7-45-EA@VCenter60:443/?moid=vm-897 
            $vmrcUrlFormat = "vmrc://clone:{0}@{1}/?moid={2}"
            $vmrcUrl = [string]::Format($vmrcUrlFormat,$ticket,$vCenterHost,$moid)


            $details = @{
                            Type = "Url"
                            Url = $vmrcUrl
            }
            $scriptResult = Get-ScriptResult $true 0 "Your Console link will be opened in a separate browser window. Please ensure that you have enabled POPUPs for this website." $details
            return $scriptResult
        }
    }
    else
    {
        throw "Failure adding disk to the VM. The parent folder/resource pool is not found."
    }
}
catch 
{
    $errorMessage = $_.Exception.Message
    $exception = Get-FullLastError
    return Get-ScriptErrorResult $errorMessage $exception  
}
