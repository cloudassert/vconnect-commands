# *************************************************************************************** #
# Change Root password VM
# *************************************************************************************** #

#
# *************************************************************************************** #
# Params in @(paramName) will be replaced by vConnect. These are standard, DO NOT CHANGE
# *************************************************************************************** #

<# End Of Arguments #>

# Common Functions - Do not Remove this
. .\ExtensionsCommon.ps1


# *************************************************************************************** #
# Do custom processing here.
# *************************************************************************************** #

try 
{   
    $connection = VConnect-Connect-VIServer -Server $HostServerName -Port $HostServerPort -User $UserName -Password $Password
    $location = VConnect-GetLocation $Datacenter $Cluster $FolderName $RootFolderPath $ResourcePoolName $false
    if($location) 
    {
        $vm = $location | Get-VM -Name $VMName
        if($vm ) 
        {
	       if ($vm.Guest.GuestFamily -eq 'linuxGuest')
           {
   
                if($CurrentRootPassword -eq $null -or $RootPassword -eq $null)
                {
                    return Get-ScriptResult -isSuccess $true -errorCode 0 -message "Skipped."
                }

                try 
                {   
                    $update = "echo '" + $RootPassword +"' | passwd root --stdin"
                    $vresult = Invoke-VMScript -VM $vm -ScriptText $update -GuestUser root -GuestPassword $CurrentRootPassword -scripttype bash
                }
                catch 
                {
                    # Exception Ignored:
                    # Exception is thrown after the Invoke-VMScript command successfully completes resetting the root user password. 
                    # This is because of using root user to reset root users self password
                }

                # Validate that the new password has taken effect by running a sample command
                $test = "dir"
                $vresult2 = Invoke-VMScript -VM $vm -ScriptText $test -GuestUser root -GuestPassword $RootPassword -scripttype bash
                
                if (!$?)
                {
                    $errorMessage = "Failure changing the root password for VM.`nError Message:`n"
                    $errorMessage += $error[0].ToString()
                    throw $errorMessage 
                }
                $resultObj = @{
                    IsSuccess = $true
                    Message = $errorMessage
                    ErrorCode = -1
                    Exception = $exception
                    Details = $null
                }
				$result = New-Object PSObject -Property $resultObj
				return Get-ScriptResult $true 0 "Changing root password Succeeded" $result  
            }
		}
		else
		{
			throw "Failure changing the root password. The VM is not found."
		}
    }
	else
	{
		throw "Failure changing the root password. The parent folder/resource pool is not found."
	}
}
catch 
{
    $errorMessage = $_.Exception.Message
    $exception = Get-FullLastError
    return Get-ScriptErrorResult $errorMessage $exception  
}