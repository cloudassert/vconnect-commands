﻿try 
{
    Import-Module 'C:\inetpub\MgmtSvc-CloudAssert-VConnect\VConnectVMWareModule.psm1'
    if (!$?)
    {
        $errorMessage = "Failure loading the module.`nError Message:`n"
        $errorMessage += $error[0].ToString()
        throw $errorMessage
    } 
    $connection = VConnect-Init $HostServerName $HostServerPort $UserName $Password
    $vm = VConnect-MountIso $Datacenter $Cluster $FolderName $RootFolderPath $ResourcePoolName $VMName $newisopath
    if (!$?)
    {
        $errorMessage = "Failure mounting ISO to VM.`nError Message:`n"
        $errorMessage += $error[0].ToString()
        throw $errorMessage
    } 

    # *************************************************************************************** #
    # Construct Result object, this is standard, DO NOT change the property names or object types:
    # *************************************************************************************** #
    $message = "Successfully Mounted ISO to VM: '" + $vm.Name + "' ISO: '" + $newisopath +"'"
    $resultProps = @{ 
                    VMName = $vm.Name
                    VMId = $vm.Id
                    PowerState = $vm.PowerState
                }  
    $result = New-Object PSObject -Property $resultProps

    return VConnect-GetScriptResult $true 0 $message $result
}
catch 
{
    $errorMessage = $_.Exception.Message
    $exception = VConnect-GetFullLastError
    return VConnect-GetScriptErrorResult $errorMessage $exception        
}
