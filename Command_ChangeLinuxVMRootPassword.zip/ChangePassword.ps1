# *************************************************************************************** #
# Change Root password VM
# *************************************************************************************** #

#
# *************************************************************************************** #
# Params in @(paramName) will be replaced by vConnect. These are standard, DO NOT CHANGE
# *************************************************************************************** #

<# End Of Arguments #>

# Common Functions - Do not Remove this
. .\ExtensionsCommon.ps1


# *************************************************************************************** #
# Do custom processing here.
# *************************************************************************************** #

try 
{   
    $connection =  VConnect-Connect-VIServer-V2 -Server $HostServerName -Port $HostServerPort -User $UserName -Password $Password
    $location = VConnect-GetLocation $Datacenter $Cluster $FolderName $RootFolderPath $ResourcePoolName $false $connection 
    if($location) 
    {
        $vm = $location | Get-VM -Name $VMName -Server $connection
        if($vm ) 
        {
	       if ($vm.Guest.GuestFamily -eq 'linuxGuest')
           {
   
                if($CurrentRootPassword -eq $null -or $NewRootPassword -eq $null)
                {
                    return Get-ScriptResult -isSuccess $true -errorCode 0 -message "Password Null. Skipped."
                }

                try 
                {   
                    if($RootUser -eq 'root')
                    {
                        if ($vm.Guest.OSFullName -like '*Debian*')
                        {
                            # For Debian, the --stdin commnad doesnot work
                            $update = "echo -e '"+ $NewRootPassword +"\n"+$NewRootPassword+"' | passwd $RootUser " 
                        }
                        else
                        {
                            $update = "echo '" + $NewRootPassword +"' | passwd $RootUser --stdin"
                        }
                    }
                    else
                    {
                        # For Ubuntu we pass the user who has root previleges
                        $update = "echo -e '"+ $CurrentRootPassword+ "\n"+$NewRootPassword +"\n"+$NewRootPassword+"' | passwd $RootUser " 
                    }
                    $vresult = Invoke-VMScript -VM $vm -ScriptText $update -GuestUser $RootUser -GuestPassword $CurrentRootPassword -Server $connection -scripttype bash
                }
                catch 
                {
                    # Exception Ignored:
                    # Exception is thrown after the Invoke-VMScript command successfully completes resetting the root user password. 
                    # This is because of using root user to reset root users self password
                }

                # Validate that the new password has taken effect by running a sample command
                $test = "dir"
                $vresult2 = Invoke-VMScript -VM $vm -ScriptText $test -GuestUser $RootUser -GuestPassword $NewRootPassword -scripttype bash
                
                if (!$vresult2)
                {
                    $errorMessage = "Failure changing the root password for VM.`nError Message:`n"
                    $errorMessage += $error[0].ToString()
                    throw $errorMessage 
                }
                $resultObj = @{
                    IsSuccess = $true
                    Message = $errorMessage
                    ErrorCode = -1
                    Exception = $exception
                    Details = $null
                }
				$result = New-Object PSObject -Property $resultObj
				return Get-ScriptResult $true 0 "Changing root password Succeeded" $result  
            }
            else
            {
                return Get-ScriptErrorResult "VM Not Linux" "VM Not Linux Root Password Reset Not Success!"
            }
		}
		else
		{
			return Get-ScriptErrorResult "VM Not found" "VM Not found Root Password Reset Not Success!"
		}
    }
	else
	{
        return Get-ScriptErrorResult "The parent folder/resource pool is not found." "Root Password Reset Not Success!"		
	}
}
catch 
{
    $errorMessage = $_.Exception.Message
    $exception = Get-FullLastError
    return Get-ScriptErrorResult $errorMessage $exception  
}