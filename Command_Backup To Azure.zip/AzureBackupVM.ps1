﻿# Following Param Values will be provided via Custom Command parameters matching the same name
#$backupStorageResourceGroup = ''
#$backupStorageAccountName = ''
#$backupStorageAccountNameKey = ''
#$backupContainerName = ''

$nl = [Environment]::NewLine

Import-Module Azure.Storage

function Get-ScriptResult { 
param([bool] $isSuccess,
      [int] $errorCode,
      [string] $message, 						  
      [PSObject] $details)
    
	if($details -ne $null) 
    {
        $detailsJson = ConvertTo-Json -InputObject $details -Compress
    }

    $result = @{ 
                    IsSuccess = $isSuccess
                    Message = $message
                    ErrorCode = $errorCode
                    Exception = ""
                    Details = $details
		            DetailsJson = $detailsJson
                }  
    return New-Object PSObject -Property $result
}


function Copy-AzureBlob
{
    [CmdletBinding()]
    [OutputType([int])]
    Param
    (
        # Param1 help description
        [string] $sourceUri,
        [string] $dstBlobName,
       [string] $dstContainerName
    )

        $storageContext = New-AzureStorageContext -StorageAccountName $backupStorageAccountName -StorageAccountKey $backupStorageAccountKey
        $copyResult = Start-AzureStorageBlobCopy -AbsoluteUri $sourceUri -DestContainer $dstContainerName -DestBlob $dstBlobName -DestContext $storageContext
        $status = Get-AzureStorageBlobCopyState -Blob $dstBlobName -Container $dstContainerName -Context $storageContext -WaitForComplete
        return $status
}

function Backup-AzureVMDisk
{
    [CmdletBinding()]
    [OutputType([int])]
    Param
    (
        $vmName,
        $diskType,
        $disk, 
        [string] $backupContainerName
    )
        $sourceUri= $disk.Vhd.Uri
        $backupName = $vmName + $diskType + $timeStamp +".vhd"
        $copyResult = Copy-AzureBlob -sourceUri $sourceUri -dstBlobName $backupName -dstContainerName $backupContainerName 
        return $copyResult;
}


function Backup-AzureVM
{
    Param
    (
        # Param1 help description
        [Parameter(Mandatory=$true)]
        [string] $resourceGroupName,
        [Parameter(Mandatory=$true)]
        [string] $vmName,
        [Parameter(Mandatory=$true)]
        [string] $backupContainerName,
        [Parameter(Mandatory=$true)]
        [string] $backupStorageAccountName,
        [switch] $includeDataDisks
    )
    
    $backupResult = @{
        NumberOfDisks = 0
        SuccessDisks = 0
        FailedDisks = 0
        TotalBytesCopied = 0
        IsSuccess = $true
        Message = ""
    }
    $timeStamp = (get-date).ToString('yyyyMMdd-HHmm')
    $vm = Get-AzureRmVM -Name $ResourceName -ResourceGroupName $ResourceGroupName
    
    if (! $vm)
    {
        $backupResult.Message = "Virtual machine $vmName not found in service $serviceName"
        $backupResult.IsSuccess = $false
        return $backupResult;
    }
    $osDisk = $vm.StorageProfile.OsDisk
    $osDiskUrl = $osDisk.Vhd.Uri
    $dataDisks = $vm.StorageProfile.DataDisks
    $error.clear()
    $status = Backup-AzureVMDisk  -vmName $vm.Name -diskType "OSDisk" -backupContainerName $backupContainerName -disk $osDisk 
    if ($status.Status -eq 'Success')
    {
        $backupResult.Message += " Backup Completed for OsDisk: '$osDiskUrl'"
        $backupResult.TotalBytesCopied += $status.BytesCopied
        $backupResult.NumberOfDisks += 1
        $backupResult.SuccessDisks += 1
    }
    else
    {
        $errorMessage = $error[0] | out-string
        $backupResult.Message += " Backup Failed for Os Disk '$osDiskUrl'." + " Context: " + $backupStorageAccount.Context + "Error: " + $errorMessage  
        $backupResult.NumberOfDisks += 1
        $backupResult.FailedDisks += 1
    }
    if ($includeDataDisks)
    {
        foreach($disk in $dataDisks)
        {
            $status = Backup-AzureVMDisk  -vmName $vm.Name -diskType "DataDisk" -backupContainerName $backupContainerName -disk $disk
            $diskUrl = $disk.Vhd.Uri
                if ($status.Status -eq 'Success')
                {
                    $backupResult.Message += " Backup Completed for DataDisk: '$diskUrl'"
                    $backupResult.TotalBytesCopied += $status.BytesCopied
                    $backupResult.NumberOfDisks += 1
                    $backupResult.SuccessDisks += 1
                }
                else
                {
                    $errorMessage = $error[0] | out-string
                    $backupResult.Message += " Backup Failed for Data Disk '$diskUrl'" + $errorMessage
                    $backupResult.NumberOfDisks += 1
                    $backupResult.FailedDisks += 1
                }      
        }
    }
    return $backupResult;
}

$secpasswd = ConvertTo-SecureString $AADApplicationPassword -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential ($AADApplicationId, $secpasswd)
$login = Login-AzureRmAccount -ServicePrincipal -Tenant $AADSubscriptionTenantId -Credential $mycreds
if($login -eq $null) {
    $result = @{ 
                    IsSuccess = $false
                    Message = "Login failed. " + $error[0]
                    ErrorCode = 0
           }  

    return New-Object PSObject -Property $result
} 

$bresult = Backup-AzureVM -resourceGroupName $ResourceGroupName -vmName $ResourceName -backupStorageAccountName $backupStorageAccountName -backupContainerName $backupContainerName -includeDataDisks
$issuccess = $bresult.NumberOfDisks -eq $bresult.SuccessDisks
$Message = "Total Disks: " + $bresult.NumberOfDisks + " Success Disks: " + $bresult.SuccessDisks + " Total Bytes Copied: " + [math]::Round($bresult.TotalBytesCopied / 1024 /1024 / 1024, 0) + " GB"
$Message += $bresult.Message
$bytesText = $bresult.TotalBytesCopied

 $html = '<h1>Azure Backup Summary</h1>'
 $html += '<table border="1"><tbody>'
     $html += '<tr>'
         $html += '<td>'
         $html += 'Total Disks'
         $html += '</td>'
         $html += '<td>'
         $html += $bresult.NumberOfDisks
         $html += '</td>'
     $html += '</tr>'
     $html += '<tr>'
         $html += '<td>'
         $html += 'Disks Succeeded'
         $html += '</td>'
         $html += '<td>'
         $html += $bresult.SuccessDisks
         $html += '</td>'
     $html += '</tr>'
     $html += '<tr>'
         $html += '<td>'
         $html += 'Total Copied'
         $html += '</td>'
         $html += '<td>'
         $html += $bresult.TotalBytesCopied
         $html += '</td>'
     $html += '</tr>'
     $html += '<tr>'
         $html += '<td>'
         $html += 'Message'
         $html += '</td>'
         $html += '<td>'
         $html += $bresult.Message
         $html += '</td>'
     $html += '</tr>'
$html += '</tbody></table>'
 $details = @{
            Type = "Html"
            Html = $html
}
Get-ScriptResult $issuccess 0 "Backup Completed" $details