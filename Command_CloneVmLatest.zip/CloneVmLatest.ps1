# *************************************************************************************** #
# Cloning VM
# *************************************************************************************** #


# *************************************************************************************** #
# Params in @(paramName) will be replaced by vConnect. These are standard, DO NOT CHANGE
# *************************************************************************************** #

<# End Of Arguments #>

# Common Functions - Do not Remove this
. .\ExtensionsCommon.ps1


# *************************************************************************************** #
# Do custom processing here.

# *************************************************************************************** #

function VConnect-SelectDataStoreForVM-V2 {
param($allDataStores, $requiredDiskGB, $dataStoreHint)
    $resultExact = $null
    $resultContains = $null
    $resultAny = $null

    $freeSpaceComputeExpression = {$_.CapacityGB - ($_.ExtensionData.Summary.Capacity - $_.Extensiondata.Summary.FreeSpace + $_.ExtensionData.Summary.Uncommitted)/1GB}
    $freeSpaceColumnDefn = @{ Name = 'FreeSpace'; Expression = $freeSpaceComputeExpression }
    # sorted by Free Space and Capacity
    $sortedDatastores = $private:allDataStores | Sort-Object -Descending $freeSpaceComputeExpression,CapacityGB
    foreach ($ds in $private:sortedDatastores) {
        $dsview = $ds | Get-View
        if($dsview.Host.MountInfo.AccessMode -ne 'readOnly') {            
            $actualFreeSpace = $ds | select-object $freeSpaceColumnDefn
            if ($actualFreeSpace.FreeSpace -ge $requiredDiskGB) {
                if ($private:dataStoreHint) {
                    if ($ds -eq $private:dataStoreHint) {
                        $resultExact = $ds;
                        break;
                    }
                    if ($ds -Match $private:dataStoreHint) {
                        $resultContains = $ds;
                    }
                } else {
                    $resultAny = $ds
                    break;
                }            
            }
        }
    }

    if ($resultExact) {
        $result = @{
            Datastore = $resultExact
            ErrorMessage = $null
        }
    } elseif($resultContains)
	{
        $result = @{
        Datastore = $resultContains
        ErrorMessage = $null
        }
	} elseif($resultAny)
	{
        $result = @{
        Datastore = $resultAny
        ErrorMessage = $null
        }
	} else {
        $errorMsg = "Datastore not found to clone the VM.`n"
        $errorMsg += "Number of Datastores found: $($private:allDataStores.Count)`n" 
        if($private:dataStoreHint) {
            $errorMsg += "No Datastores found with matching DataStoreHint '$($private:DataStoreHint)'`n"
        }
        $errorMsg += "Free space required: $($private:requiredDiskGB) GB`n"
        $result = @{
            Datastore = $null
            ErrorMessage = $errorMsg
        }
    }
    return $result
}


try 
{   
    $connection = VConnect-Connect-VIServer-V2 -ErrorAction Stop
    
    $location = VConnect-GetLocation $Datacenter $Cluster $FolderName $RootFolderPath $ResourcePoolName $false $connection
    if($location) 
    {
        $newVm = Get-VM -Name $NewVMName -Server $connection
        $originalVM = $location | Get-VM -Name $VMName -Server $connection
        $VMHost = Get-VMHost -VM $VMName -Server $connection
        if($originalVM ) 
        {
            $memoryMB = $originalVM.MemoryMB

            # Get the Hard Disks size of the original VM
            $hardDisks = $originalVM | Get-HardDisk | Measure-Object 'CapacityGB' -Sum
            $diskGB = $hardDisks.Sum 
            
            # Minimum space required = (Size of template's hard disk(s)) + (size of RAM for virtual machine) + ( 100 MB for log files per virtual machine)
            $diskSpaceRequiredGB = $diskGB + ($memoryMB / 1024) + (100 / 1024) 
            
            # Folder where the Original VM is placed
            $folder =  VConnect-GetVMFolder $FolderName $Datacenter $RootFolderPath $false $connection 
            
            # Get Accessible Datastores of this VCenter Cluster
            $vcenterCluster = Get-Cluster -Name $Cluster -Server $connection
            $allDataStores = $vcenterCluster  | Get-DataStore | ?{ $_.Accessible }
            
            # Find the relevant Datastore
            $dataStoreResult = VConnect-SelectDataStoreForVM-V2  $allDataStores $diskSpaceRequiredGB $DataStoreHint -Server $connection
            $dataStore = $dataStoreResult.DataStore 
            if (!$dataStore)
            {
               throw $dataStoreResult.ErrorMessage
            }
            $dataStoreName = $dataStore.Name    
            if($newVm )
            {
               throw "Failure Cloning the VM. The VM with the specified name already exists."
            }
            $clonedVM = New-VM -Name $NewVMName -VM $originalVM -Datastore $dataStoreName -VMHost $VMHost -Location $folder -ResourcePool $ResourcePoolName -Server $connection        
            $clonedVM | Start-VM -ErrorAction Stop -Server $connection
            if (!$?)
            {
                $errorMessage = "Failure cloning the VM.`nError Message:`n"
                $errorMessage += $error[0].ToString()
                throw $errorMessage 
            }
            $resultObj = @{
                NewVMName = $clonedVM.Name
            }
            $result = New-Object PSObject -Property $resultObj
            return Get-ScriptResult $true 0 "Cloning of the VM Succeeded" $result	   
        }
    }
    else
    {
        throw "Failure cloning the VM. The parent folder/resource pool is not found."
    }
}
catch 
{
    $errorMessage = $_.Exception.Message
    $exception = Get-FullLastError
    return Get-ScriptErrorResult $errorMessage $exception  
}
finally
{
    Disconnect-VIServer -Server $connection -Confirm:$false
}