# *************************************************************************************** #
# Adding Network Adapter VM
# *************************************************************************************** #

#
# *************************************************************************************** #
# Params in @(paramName) will be replaced by vConnect. These are standard, DO NOT CHANGE
# *************************************************************************************** #

<# End Of Arguments #>

# Common Functions - Do not Remove this
. .\ExtensionsCommon.ps1


# *************************************************************************************** #
# Do custom processing here.
# *************************************************************************************** #

try 
{   
    $connection = VConnect-Connect-VIServer -Server $HostServerName -Port $HostServerPort -User $UserName -Password $Password
    $location = VConnect-GetLocation $Datacenter $Cluster $FolderName $RootFolderPath $ResourcePoolName $false
    if($location) 
    {
        $vm = $location | Get-VM -Name $VMName
        if($vm ) 
        {
	    if($IsDistributedSwitch -eq $true)
	    {
		$portGroup = Get-VDPortgroup -Name $NetworkName 
		$network = New-NetworkAdapter -VM $vm -PortGroup $portGroup -Type $NetworkAdapterType -StartConnected
	    }
	    else
	    {
		$network = New-NetworkAdapter -VM $vm -NetworkName $NetworkName -Type $NetworkAdapterType -StartConnected
	    }
	   
            if (!$?)
            {
                $errorMessage = "Failure adding network to the VM.`nError Message:`n"
                $errorMessage += $error[0].ToString()
                throw $errorMessage 
            }
            $resultObj = @{
                    IsSuccess = $true
                    Message = $errorMessage
                    ErrorCode = -1
                    Exception = $exception
                    Details = $null
            }
            $result = New-Object PSObject -Property $resultObj
            return Get-ScriptResult $true 0 "Adding Network to the VM Succeeded" $result    
        }
    }
    else
    {
        throw "Failure adding the network adapter to the VM. The parent folder/resource pool is not found."
    }
}
catch 
{
    $errorMessage = $_.Exception.Message
    $exception = Get-FullLastError
    return Get-ScriptErrorResult $errorMessage $exception  
}